﻿using System;
namespace _03.PlayersAndMonsters
{
	public class BladeKnight : DarkKnight
	{
        public BladeKnight(string username, int level) : base(username, level)
        {

        }
    }
}

