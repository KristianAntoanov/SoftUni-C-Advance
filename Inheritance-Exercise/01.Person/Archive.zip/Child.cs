﻿using System;
namespace _01.Person
{
	public class Child : Person
	{
		public Child(string Name, int Age) : base(Name, Age)
		{

		}

	}
}

