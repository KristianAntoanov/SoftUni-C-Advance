﻿using System;
namespace _02.Zoo
{
	public class Reptile : Animal
	{
		public Reptile(string Name) : base(Name)
		{

		}
	}
}

