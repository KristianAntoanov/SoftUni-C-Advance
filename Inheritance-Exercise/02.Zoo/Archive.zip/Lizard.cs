﻿using System;
namespace _02.Zoo
{
	public class Lizard : Reptile
	{
        public Lizard(string Name) : base(Name)
        {

        }
    }
}

