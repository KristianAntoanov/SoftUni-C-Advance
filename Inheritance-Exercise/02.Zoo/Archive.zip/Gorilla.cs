﻿using System;
namespace _02.Zoo
{
	public class Gorilla : Mammal
	{
        public Gorilla(string Name) : base(Name)
        {

        }
    }
}

