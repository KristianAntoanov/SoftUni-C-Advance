﻿using System;
namespace _02.Zoo
{
	public class Animal
	{
        public Animal(string name)
        {
            Name = name;
        }

        public string Name { get; set; }
	}
}

