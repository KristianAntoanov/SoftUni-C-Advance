﻿using System;
namespace _02.Zoo
{
	public class Bear : Mammal
	{
        public Bear(string Name) : base(Name)
        {

        }
    }
}

