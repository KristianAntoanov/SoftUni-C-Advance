﻿using System;
namespace _02.Zoo
{
	public class Mammal : Animal
	{
        public Mammal(string Name) : base(Name)
        {

        }
    }
}

