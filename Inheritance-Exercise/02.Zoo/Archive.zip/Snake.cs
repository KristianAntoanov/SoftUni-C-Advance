﻿using System;
namespace _02.Zoo
{
	public class Snake : Reptile
	{
        public Snake(string Name) : base(Name)
        {

        }
    }
}

