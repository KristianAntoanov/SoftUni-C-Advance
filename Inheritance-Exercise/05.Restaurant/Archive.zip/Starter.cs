﻿using System;
namespace _05.Restaurant
{
    public class Starter : Food
    {
        public Starter(string name, decimal price, double grams) : base(name, price, grams)
        {

        }
    }
}

