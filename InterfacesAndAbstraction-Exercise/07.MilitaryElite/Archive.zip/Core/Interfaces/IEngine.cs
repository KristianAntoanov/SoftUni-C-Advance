﻿using System;
namespace MilitaryElite
{
	public interface IEngine
	{
		void Run();
	}
}

