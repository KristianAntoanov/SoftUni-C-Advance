﻿using System;
namespace _07.MilitaryElite.Enums
{
	public enum Corps
	{
		Airforces,
		Marines
	}
}

