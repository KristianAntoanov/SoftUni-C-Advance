﻿using System;
namespace _07.MilitaryElite.Enums
{
	public enum State
	{
		inProgress,
		Finished
	}
}

