﻿using System;
namespace FoodShortage
{
	public interface IEngine
	{
		void Run();
	}
}

