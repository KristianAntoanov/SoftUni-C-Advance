﻿using System;
namespace FoodShortage.Models.Iterfaces
{
	public interface IIdentifiable
	{
        string Id { get; }
	}
}

