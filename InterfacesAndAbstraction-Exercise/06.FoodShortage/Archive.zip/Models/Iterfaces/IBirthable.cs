﻿using System;
namespace FoodShortage.Models.Iterfaces
{
	public interface IBirthable
	{
        string Birthdate { get; }
    }
}

