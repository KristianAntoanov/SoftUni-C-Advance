﻿using System;
namespace FoodShortage.Models.Iterfaces
{
	public interface INameable
	{
		string Name { get; }
	}
}

