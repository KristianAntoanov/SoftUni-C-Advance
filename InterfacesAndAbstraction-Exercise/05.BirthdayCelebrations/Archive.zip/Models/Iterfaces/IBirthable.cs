﻿using System;
namespace _05.BirthdayCelebrations.Models.Iterfaces
{
	public interface IBirthable
	{
        string Birthdate { get; }
    }
}

