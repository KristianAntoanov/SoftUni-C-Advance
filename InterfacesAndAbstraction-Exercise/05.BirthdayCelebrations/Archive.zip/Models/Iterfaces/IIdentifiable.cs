﻿using System;
namespace BirthdayCelebrations.Models.Iterfaces
{
	public interface IIdentifiable
	{
        string Id { get; }
	}
}

