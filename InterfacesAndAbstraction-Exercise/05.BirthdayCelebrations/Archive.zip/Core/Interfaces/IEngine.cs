﻿using System;
namespace BirthdayCelebrations
{
	public interface IEngine
	{
		void Run();
	}
}

